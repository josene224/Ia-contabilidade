import { FileText, Download, Printer, ChevronRight } from "lucide-react";
import { balancoData } from "@/data/mockData";

const formatCurrency = (value: number) => {
  return new Intl.NumberFormat("pt-AO", {
    style: "currency",
    currency: "AOA",
    minimumFractionDigits: 0,
  }).format(value);
};

export default function Balanco() {
  const totalActivoNaoCorrente = balancoData.activo.naoCorrente.reduce(
    (sum, item) => sum + item.valor,
    0
  );
  const totalActivoCorrente = balancoData.activo.corrente.reduce(
    (sum, item) => sum + item.valor,
    0
  );
  const totalActivo = totalActivoNaoCorrente + totalActivoCorrente;

  const totalCapitalProprio = balancoData.capitalProprio.reduce(
    (sum, item) => sum + item.valor,
    0
  );
  const totalPassivoNaoCorrente = balancoData.passivo.naoCorrente.reduce(
    (sum, item) => sum + item.valor,
    0
  );
  const totalPassivoCorrente = balancoData.passivo.corrente.reduce(
    (sum, item) => sum + item.valor,
    0
  );
  const totalPassivo = totalCapitalProprio + totalPassivoNaoCorrente + totalPassivoCorrente;

  return (
    <div className="min-h-screen">
      {/* Header */}
      <header className="sticky top-0 z-10 bg-background/80 backdrop-blur-lg border-b border-border">
        <div className="flex items-center justify-between px-6 py-4">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center">
              <FileText className="w-6 h-6 text-primary" />
            </div>
            <div>
              <h1 className="text-2xl font-bold">Balanço Patrimonial</h1>
              <p className="text-sm text-muted-foreground">
                Estrutura conforme PGC Angolano • 31 Dezembro 2024
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button className="flex items-center gap-2 px-4 py-2 bg-secondary hover:bg-secondary/80 rounded-lg transition-colors">
              <Printer className="w-4 h-4" />
              <span className="text-sm font-medium">Imprimir</span>
            </button>
            <button className="flex items-center gap-2 px-4 py-2 bg-primary text-primary-foreground hover:bg-primary/90 rounded-lg transition-colors">
              <Download className="w-4 h-4" />
              <span className="text-sm font-medium">Exportar</span>
            </button>
          </div>
        </div>
      </header>

      {/* Content */}
      <div className="p-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* ACTIVO */}
          <div className="bg-card rounded-xl border border-border shadow-card animate-fade-up">
            <div className="p-4 border-b border-border bg-primary/5">
              <h2 className="text-lg font-bold text-primary">ACTIVO</h2>
            </div>
            <div className="p-4 space-y-6">
              {/* Activo Não Corrente */}
              <div>
                <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-wide mb-3">
                  Activo Não Corrente
                </h3>
                <div className="space-y-2">
                  {balancoData.activo.naoCorrente.map((item) => (
                    <div
                      key={item.conta}
                      className="flex items-center justify-between py-2 px-3 hover:bg-secondary/50 rounded-lg transition-colors"
                    >
                      <div className="flex items-center gap-2">
                        <ChevronRight className="w-4 h-4 text-muted-foreground" />
                        <span className="text-sm">
                          <span className="font-mono text-primary">{item.conta}</span> -{" "}
                          {item.descricao}
                        </span>
                      </div>
                      <span
                        className={`font-mono text-sm ${
                          item.valor < 0 ? "text-destructive" : ""
                        }`}
                      >
                        {formatCurrency(item.valor)}
                      </span>
                    </div>
                  ))}
                </div>
                <div className="mt-3 pt-3 border-t border-border flex justify-between px-3">
                  <span className="font-medium">Subtotal</span>
                  <span className="font-mono font-semibold">
                    {formatCurrency(totalActivoNaoCorrente)}
                  </span>
                </div>
              </div>

              {/* Activo Corrente */}
              <div>
                <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-wide mb-3">
                  Activo Corrente
                </h3>
                <div className="space-y-2">
                  {balancoData.activo.corrente.map((item) => (
                    <div
                      key={item.conta}
                      className="flex items-center justify-between py-2 px-3 hover:bg-secondary/50 rounded-lg transition-colors"
                    >
                      <div className="flex items-center gap-2">
                        <ChevronRight className="w-4 h-4 text-muted-foreground" />
                        <span className="text-sm">
                          <span className="font-mono text-primary">{item.conta}</span> -{" "}
                          {item.descricao}
                        </span>
                      </div>
                      <span className="font-mono text-sm">
                        {formatCurrency(item.valor)}
                      </span>
                    </div>
                  ))}
                </div>
                <div className="mt-3 pt-3 border-t border-border flex justify-between px-3">
                  <span className="font-medium">Subtotal</span>
                  <span className="font-mono font-semibold">
                    {formatCurrency(totalActivoCorrente)}
                  </span>
                </div>
              </div>

              {/* Total Activo */}
              <div className="bg-primary/10 rounded-lg p-4 flex justify-between items-center">
                <span className="font-bold text-primary">TOTAL ACTIVO</span>
                <span className="font-mono font-bold text-xl text-primary">
                  {formatCurrency(totalActivo)}
                </span>
              </div>
            </div>
          </div>

          {/* CAPITAL PRÓPRIO E PASSIVO */}
          <div className="bg-card rounded-xl border border-border shadow-card animate-fade-up">
            <div className="p-4 border-b border-border bg-success/5">
              <h2 className="text-lg font-bold text-success">CAPITAL PRÓPRIO E PASSIVO</h2>
            </div>
            <div className="p-4 space-y-6">
              {/* Capital Próprio */}
              <div>
                <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-wide mb-3">
                  Capital Próprio
                </h3>
                <div className="space-y-2">
                  {balancoData.capitalProprio.map((item) => (
                    <div
                      key={item.conta}
                      className="flex items-center justify-between py-2 px-3 hover:bg-secondary/50 rounded-lg transition-colors"
                    >
                      <div className="flex items-center gap-2">
                        <ChevronRight className="w-4 h-4 text-muted-foreground" />
                        <span className="text-sm">
                          <span className="font-mono text-success">{item.conta}</span> -{" "}
                          {item.descricao}
                        </span>
                      </div>
                      <span className="font-mono text-sm">
                        {formatCurrency(item.valor)}
                      </span>
                    </div>
                  ))}
                </div>
                <div className="mt-3 pt-3 border-t border-border flex justify-between px-3">
                  <span className="font-medium">Subtotal</span>
                  <span className="font-mono font-semibold">
                    {formatCurrency(totalCapitalProprio)}
                  </span>
                </div>
              </div>

              {/* Passivo Não Corrente */}
              <div>
                <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-wide mb-3">
                  Passivo Não Corrente
                </h3>
                <div className="space-y-2">
                  {balancoData.passivo.naoCorrente.map((item) => (
                    <div
                      key={item.conta}
                      className="flex items-center justify-between py-2 px-3 hover:bg-secondary/50 rounded-lg transition-colors"
                    >
                      <div className="flex items-center gap-2">
                        <ChevronRight className="w-4 h-4 text-muted-foreground" />
                        <span className="text-sm">
                          <span className="font-mono text-warning">{item.conta}</span> -{" "}
                          {item.descricao}
                        </span>
                      </div>
                      <span className="font-mono text-sm">
                        {formatCurrency(item.valor)}
                      </span>
                    </div>
                  ))}
                </div>
                <div className="mt-3 pt-3 border-t border-border flex justify-between px-3">
                  <span className="font-medium">Subtotal</span>
                  <span className="font-mono font-semibold">
                    {formatCurrency(totalPassivoNaoCorrente)}
                  </span>
                </div>
              </div>

              {/* Passivo Corrente */}
              <div>
                <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-wide mb-3">
                  Passivo Corrente
                </h3>
                <div className="space-y-2">
                  {balancoData.passivo.corrente.map((item) => (
                    <div
                      key={item.conta}
                      className="flex items-center justify-between py-2 px-3 hover:bg-secondary/50 rounded-lg transition-colors"
                    >
                      <div className="flex items-center gap-2">
                        <ChevronRight className="w-4 h-4 text-muted-foreground" />
                        <span className="text-sm">
                          <span className="font-mono text-warning">{item.conta}</span> -{" "}
                          {item.descricao}
                        </span>
                      </div>
                      <span className="font-mono text-sm">
                        {formatCurrency(item.valor)}
                      </span>
                    </div>
                  ))}
                </div>
                <div className="mt-3 pt-3 border-t border-border flex justify-between px-3">
                  <span className="font-medium">Subtotal</span>
                  <span className="font-mono font-semibold">
                    {formatCurrency(totalPassivoCorrente)}
                  </span>
                </div>
              </div>

              {/* Total Passivo */}
              <div className="bg-success/10 rounded-lg p-4 flex justify-between items-center">
                <span className="font-bold text-success">TOTAL CAP. PRÓPRIO + PASSIVO</span>
                <span className="font-mono font-bold text-xl text-success">
                  {formatCurrency(totalPassivo)}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Verification */}
        <div className="mt-6 bg-card rounded-xl border border-border p-6 shadow-card animate-fade-up">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div
                className={`w-12 h-12 rounded-xl flex items-center justify-center ${
                  totalActivo === totalPassivo ? "bg-success/10" : "bg-destructive/10"
                }`}
              >
                {totalActivo === totalPassivo ? (
                  <span className="text-success text-xl">✓</span>
                ) : (
                  <span className="text-destructive text-xl">✗</span>
                )}
              </div>
              <div>
                <p className="font-semibold">Verificação do Balanço</p>
                <p className="text-sm text-muted-foreground">
                  {totalActivo === totalPassivo
                    ? "O balanço está equilibrado (Activo = Passivo + Capital Próprio)"
                    : "Atenção: O balanço não está equilibrado!"}
                </p>
              </div>
            </div>
            <div className="text-right">
              <p className="text-sm text-muted-foreground">Diferença</p>
              <p
                className={`font-mono font-bold ${
                  totalActivo === totalPassivo ? "text-success" : "text-destructive"
                }`}
              >
                {formatCurrency(Math.abs(totalActivo - totalPassivo))}
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
