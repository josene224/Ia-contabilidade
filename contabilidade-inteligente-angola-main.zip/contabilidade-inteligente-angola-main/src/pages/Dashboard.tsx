import {
  Wallet,
  TrendingUp,
  ArrowDownRight,
  Receipt,
  Bell,
  Search,
  Building2,
  Menu,
} from "lucide-react";
import { MetricCard } from "@/components/dashboard/MetricCard";
import { RevenueChart } from "@/components/dashboard/RevenueChart";
import { RecentTransactions } from "@/components/dashboard/RecentTransactions";
import { AIChat } from "@/components/ai/AIChat";
import { useIsMobile } from "@/hooks/use-mobile";

const formatCurrency = (value: number) => {
  return new Intl.NumberFormat("pt-AO", {
    style: "currency",
    currency: "AOA",
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(value);
};

export default function Dashboard() {
  const isMobile = useIsMobile();

  return (
    <div className="min-h-screen">
      {/* Header */}
      <header className="sticky top-0 z-10 bg-background/80 backdrop-blur-lg border-b border-border">
        <div className="flex items-center justify-between px-4 md:px-6 py-4">
          <div>
            <h1 className="text-xl md:text-2xl font-bold">Dashboard</h1>
            <p className="text-xs md:text-sm text-muted-foreground">
              Visão geral da contabilidade
            </p>
          </div>
          <div className="flex items-center gap-2 md:gap-4">
            {!isMobile && (
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <input
                  type="text"
                  placeholder="Pesquisar..."
                  className="pl-10 pr-4 py-2 bg-secondary rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-primary w-48 lg:w-64"
                />
              </div>
            )}
            <button className="relative p-2 rounded-lg hover:bg-secondary transition-colors">
              <Bell className="w-5 h-5" />
              <span className="absolute top-1 right-1 w-2 h-2 bg-destructive rounded-full" />
            </button>
            {!isMobile && (
              <div className="flex items-center gap-3 pl-4 border-l border-border">
                <div className="w-9 h-9 rounded-full bg-primary flex items-center justify-center">
                  <Building2 className="w-5 h-5 text-primary-foreground" />
                </div>
                <div className="text-right">
                  <p className="text-sm font-medium">Empresa Demo</p>
                  <p className="text-xs text-muted-foreground">NIF: 5417892345</p>
                </div>
              </div>
            )}
          </div>
        </div>
      </header>

      {/* Main Content */}
      <div className="p-4 md:p-6 space-y-6">
        {/* Metrics Row */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-6">
          <MetricCard
            title="Total Activo"
            value={formatCurrency(79800000)}
            change={8.2}
            icon={<Wallet className="w-5 h-5 md:w-6 md:h-6" />}
            variant="primary"
          />
          <MetricCard
            title="Receitas do Mês"
            value={formatCurrency(7200000)}
            change={12.5}
            icon={<TrendingUp className="w-5 h-5 md:w-6 md:h-6" />}
            variant="success"
          />
          <MetricCard
            title="Despesas do Mês"
            value={formatCurrency(4200000)}
            change={-3.2}
            icon={<ArrowDownRight className="w-5 h-5 md:w-6 md:h-6" />}
            variant="warning"
          />
          <MetricCard
            title="Resultado Líquido"
            value={formatCurrency(4300000)}
            change={15.8}
            icon={<Receipt className="w-5 h-5 md:w-6 md:h-6" />}
            variant="success"
          />
        </div>

        {/* Charts and AI Row */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            <RevenueChart />
          </div>
          <div className="h-[400px] md:h-[440px]">
            <AIChat />
          </div>
        </div>

        {/* Transactions */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <RecentTransactions />
          <div className="bg-card rounded-xl border border-border p-4 md:p-6 shadow-card animate-fade-up">
            <h3 className="text-lg font-semibold mb-4">Alertas do Sistema</h3>
            <div className="space-y-3 md:space-y-4">
              <div className="flex items-start gap-3 p-3 bg-warning/10 rounded-lg border border-warning/20">
                <div className="w-2 h-2 mt-2 rounded-full bg-warning shrink-0" />
                <div>
                  <p className="text-sm font-medium">Reconciliação pendente</p>
                  <p className="text-xs text-muted-foreground">
                    3 movimentos bancários aguardam reconciliação
                  </p>
                </div>
              </div>
              <div className="flex items-start gap-3 p-3 bg-destructive/10 rounded-lg border border-destructive/20">
                <div className="w-2 h-2 mt-2 rounded-full bg-destructive shrink-0" />
                <div>
                  <p className="text-sm font-medium">IVA a entregar</p>
                  <p className="text-xs text-muted-foreground">
                    Prazo de entrega: 25 de Janeiro de 2024
                  </p>
                </div>
              </div>
              <div className="flex items-start gap-3 p-3 bg-primary/10 rounded-lg border border-primary/20">
                <div className="w-2 h-2 mt-2 rounded-full bg-primary shrink-0" />
                <div>
                  <p className="text-sm font-medium">Fecho mensal</p>
                  <p className="text-xs text-muted-foreground">
                    Dezembro 2023 ainda não foi encerrado
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
