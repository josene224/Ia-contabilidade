import {
  Settings,
  Building2,
  Users,
  FileText,
  Bell,
  Shield,
  Database,
  Save,
} from "lucide-react";
import { useState } from "react";

export default function Configuracoes() {
  const [activeTab, setActiveTab] = useState("empresa");

  const tabs = [
    { id: "empresa", label: "Empresa", icon: Building2 },
    { id: "utilizadores", label: "Utilizadores", icon: Users },
    { id: "documentos", label: "Documentos", icon: FileText },
    { id: "notificacoes", label: "Notificações", icon: Bell },
    { id: "seguranca", label: "Segurança", icon: Shield },
    { id: "dados", label: "Dados", icon: Database },
  ];

  return (
    <div className="min-h-screen">
      {/* Header */}
      <header className="sticky top-0 z-10 bg-background/80 backdrop-blur-lg border-b border-border">
        <div className="flex items-center justify-between px-6 py-4">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-secondary flex items-center justify-center">
              <Settings className="w-6 h-6" />
            </div>
            <div>
              <h1 className="text-2xl font-bold">Configurações</h1>
              <p className="text-sm text-muted-foreground">
                Gerir definições do sistema
              </p>
            </div>
          </div>
        </div>
      </header>

      {/* Content */}
      <div className="p-6">
        <div className="flex gap-6">
          {/* Sidebar */}
          <div className="w-64 shrink-0">
            <div className="bg-card rounded-xl border border-border shadow-card overflow-hidden">
              {tabs.map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`w-full flex items-center gap-3 px-4 py-3 text-sm font-medium transition-colors ${
                    activeTab === tab.id
                      ? "bg-primary text-primary-foreground"
                      : "hover:bg-secondary"
                  }`}
                >
                  <tab.icon className="w-5 h-5" />
                  {tab.label}
                </button>
              ))}
            </div>
          </div>

          {/* Main Content */}
          <div className="flex-1">
            {activeTab === "empresa" && (
              <div className="bg-card rounded-xl border border-border p-6 shadow-card animate-fade-up">
                <h2 className="text-lg font-semibold mb-6">
                  Informações da Empresa
                </h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium mb-2">
                      Nome da Empresa
                    </label>
                    <input
                      type="text"
                      defaultValue="Empresa Demo, Lda"
                      className="w-full px-4 py-2 bg-secondary rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-primary"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">NIF</label>
                    <input
                      type="text"
                      defaultValue="5417892345"
                      className="w-full px-4 py-2 bg-secondary rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-primary"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">
                      Email
                    </label>
                    <input
                      type="email"
                      defaultValue="contabilidade@empresademo.co.ao"
                      className="w-full px-4 py-2 bg-secondary rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-primary"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">
                      Telefone
                    </label>
                    <input
                      type="tel"
                      defaultValue="+244 923 456 789"
                      className="w-full px-4 py-2 bg-secondary rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-primary"
                    />
                  </div>
                  <div className="md:col-span-2">
                    <label className="block text-sm font-medium mb-2">
                      Endereço
                    </label>
                    <textarea
                      defaultValue="Rua Major Kanhangulo, nº 45, Maianga, Luanda, Angola"
                      rows={3}
                      className="w-full px-4 py-2 bg-secondary rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-primary resize-none"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">
                      Ano Fiscal Actual
                    </label>
                    <input
                      type="text"
                      defaultValue="2024"
                      className="w-full px-4 py-2 bg-secondary rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-primary"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">
                      Moeda
                    </label>
                    <select className="w-full px-4 py-2 bg-secondary rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-primary">
                      <option value="AOA">Kwanza (AOA)</option>
                      <option value="USD">Dólar (USD)</option>
                      <option value="EUR">Euro (EUR)</option>
                    </select>
                  </div>
                </div>
                <div className="mt-6 pt-6 border-t border-border flex justify-end">
                  <button className="flex items-center gap-2 px-6 py-2 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-colors">
                    <Save className="w-4 h-4" />
                    Guardar Alterações
                  </button>
                </div>
              </div>
            )}

            {activeTab !== "empresa" && (
              <div className="bg-card rounded-xl border border-border p-12 shadow-card text-center animate-fade-up">
                <div className="w-16 h-16 rounded-xl bg-secondary flex items-center justify-center mx-auto mb-4">
                  {tabs.find((t) => t.id === activeTab)?.icon &&
                    (() => {
                      const IconComponent = tabs.find((t) => t.id === activeTab)!.icon;
                      return <IconComponent className="w-8 h-8 text-muted-foreground" />;
                    })()}
                </div>
                <h3 className="text-lg font-semibold mb-2">
                  {tabs.find((t) => t.id === activeTab)?.label}
                </h3>
                <p className="text-muted-foreground">
                  Esta secção está em desenvolvimento. Brevemente disponível.
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
