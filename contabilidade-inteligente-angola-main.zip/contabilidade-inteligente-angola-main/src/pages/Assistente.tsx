import { AIChat } from "@/components/ai/AIChat";
import { Sparkles, BookOpen, Calculator, FileText } from "lucide-react";

const features = [
  {
    icon: BookOpen,
    title: "Consultas PGC",
    description: "Tire dúvidas sobre o Plano Geral de Contabilidade Angolano",
  },
  {
    icon: Calculator,
    title: "Lançamentos",
    description: "Aprenda como registar diferentes tipos de operações contabilísticas",
  },
  {
    icon: FileText,
    title: "Demonstrações",
    description: "Orientação sobre balanços, DR e outras demonstrações financeiras",
  },
];

export default function Assistente() {
  return (
    <div className="min-h-screen">
      {/* Header */}
      <header className="sticky top-0 z-10 bg-background/80 backdrop-blur-lg border-b border-border">
        <div className="flex items-center justify-between px-6 py-4">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-primary to-primary/60 flex items-center justify-center">
              <Sparkles className="w-6 h-6 text-primary-foreground" />
            </div>
            <div>
              <h1 className="text-2xl font-bold">Assistente ContaAI</h1>
              <p className="text-sm text-muted-foreground">
                IA especializada em contabilidade angolana
              </p>
            </div>
          </div>
        </div>
      </header>

      {/* Content */}
      <div className="p-6">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Features Panel */}
          <div className="space-y-4">
            <div className="bg-card rounded-xl border border-border p-6 shadow-card animate-fade-up">
              <h2 className="text-lg font-semibold mb-4">Como posso ajudar</h2>
              <div className="space-y-4">
                {features.map((feature, index) => (
                  <div
                    key={feature.title}
                    className="flex items-start gap-3"
                    style={{ animationDelay: `${index * 100}ms` }}
                  >
                    <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
                      <feature.icon className="w-5 h-5 text-primary" />
                    </div>
                    <div>
                      <p className="font-medium text-sm">{feature.title}</p>
                      <p className="text-xs text-muted-foreground">
                        {feature.description}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-gradient-to-br from-primary/10 to-primary/5 rounded-xl border border-primary/20 p-6 animate-fade-up">
              <h3 className="font-semibold mb-2">Dica</h3>
              <p className="text-sm text-muted-foreground">
                Faça perguntas específicas para obter respostas mais detalhadas.
                Por exemplo: "Como registar uma venda a prazo com IVA de 14%?"
              </p>
            </div>

            <div className="bg-card rounded-xl border border-border p-6 shadow-card animate-fade-up">
              <h3 className="font-semibold mb-3">Perguntas frequentes</h3>
              <ul className="space-y-2 text-sm">
                <li className="text-muted-foreground hover:text-foreground cursor-pointer transition-colors">
                  → Quais são as classes do PGC?
                </li>
                <li className="text-muted-foreground hover:text-foreground cursor-pointer transition-colors">
                  → Como calcular o resultado líquido?
                </li>
                <li className="text-muted-foreground hover:text-foreground cursor-pointer transition-colors">
                  → O que é amortização acumulada?
                </li>
                <li className="text-muted-foreground hover:text-foreground cursor-pointer transition-colors">
                  → Como registar depreciação?
                </li>
              </ul>
            </div>
          </div>

          {/* Chat Panel */}
          <div className="lg:col-span-2 h-[calc(100vh-180px)]">
            <AIChat />
          </div>
        </div>
      </div>
    </div>
  );
}
