import { Check, Star, Zap, Crown, MessageCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import lumenLogo from "@/assets/lumen-logo.png";

const WHATSAPP_NUMBER = "244957314488";
const getWhatsAppLink = (planoName: string, price: number) => {
  const message = encodeURIComponent(
    `Olá! Tenho interesse no Plano ${planoName} (${new Intl.NumberFormat("pt-AO").format(price)} Kz/mês) da Lumen AI Pro. Gostaria de saber mais sobre o processo de pagamento.`
  );
  return `https://wa.me/${WHATSAPP_NUMBER}?text=${message}`;
};

const planos = [
  {
    name: "Normal",
    price: 60000,
    icon: Star,
    description: "Ideal para pequenas empresas",
    features: [
      "Até 500 lançamentos/mês",
      "1 empresa",
      "Balanço e Demonstração de Resultados",
      "Plano de Contas PGC Angola",
      "Suporte por email",
      "Assistente IA básico",
    ],
    popular: false,
    variant: "outline" as const,
  },
  {
    name: "Premium",
    price: 90950,
    icon: Zap,
    description: "Para empresas em crescimento",
    features: [
      "Até 2.000 lançamentos/mês",
      "3 empresas",
      "Todos os relatórios financeiros",
      "Reconciliação bancária",
      "Suporte prioritário",
      "Assistente IA avançado",
      "Exportação Excel/PDF",
      "Multi-utilizadores (até 3)",
    ],
    popular: true,
    variant: "default" as const,
  },
  {
    name: "Profissional",
    price: 120999,
    icon: Crown,
    description: "Solução completa para grandes empresas",
    features: [
      "Lançamentos ilimitados",
      "Empresas ilimitadas",
      "Todos os relatórios e análises",
      "API para integrações",
      "Suporte dedicado 24/7",
      "IA com análise preditiva",
      "Auditoria e compliance",
      "Multi-utilizadores ilimitados",
      "Backup automático na cloud",
      "Formação personalizada",
    ],
    popular: false,
    variant: "outline" as const,
  },
];

const formatPrice = (value: number) => {
  return new Intl.NumberFormat("pt-AO", {
    style: "decimal",
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(value);
};

export default function Planos() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-primary/5">
      {/* Header */}
      <header className="py-6 px-4">
        <div className="max-w-6xl mx-auto flex items-center justify-between">
          <Link to="/">
            <img src={lumenLogo} alt="Lumen AI" className="h-10" />
          </Link>
          <div className="flex gap-3">
            <Link to="/login">
              <Button variant="outline" size="sm">Entrar</Button>
            </Link>
            <Link to="/registar">
              <Button size="sm">Registar</Button>
            </Link>
          </div>
        </div>
      </header>

      {/* Hero */}
      <div className="text-center px-4 py-12 md:py-16">
        <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold mb-4">
          Escolha o Plano Ideal para a Sua Empresa
        </h1>
        <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
          Contabilidade inteligente com o Plano Geral de Contabilidade de Angola.
          Comece hoje e transforme a gestão financeira da sua empresa.
        </p>
      </div>

      {/* Plans Grid */}
      <div className="max-w-6xl mx-auto px-4 pb-16">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 lg:gap-8">
          {planos.map((plano) => (
            <div
              key={plano.name}
              className={`relative bg-card rounded-2xl border p-6 lg:p-8 transition-all duration-300 hover:shadow-xl ${
                plano.popular
                  ? "border-primary shadow-lg scale-105 md:scale-110"
                  : "border-border hover:border-primary/50"
              }`}
            >
              {plano.popular && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                  <span className="bg-primary text-primary-foreground text-xs font-semibold px-3 py-1 rounded-full">
                    MAIS POPULAR
                  </span>
                </div>
              )}

              <div className="text-center mb-6">
                <div
                  className={`w-14 h-14 rounded-2xl flex items-center justify-center mx-auto mb-4 ${
                    plano.popular
                      ? "bg-primary text-primary-foreground"
                      : "bg-primary/10 text-primary"
                  }`}
                >
                  <plano.icon className="w-7 h-7" />
                </div>
                <h3 className="text-xl font-bold mb-1">Plano {plano.name}</h3>
                <p className="text-sm text-muted-foreground">{plano.description}</p>
              </div>

              <div className="text-center mb-6">
                <div className="flex items-baseline justify-center gap-1">
                  <span className="text-3xl lg:text-4xl font-bold">
                    {formatPrice(plano.price)}
                  </span>
                  <span className="text-muted-foreground">Kz</span>
                </div>
                <p className="text-xs text-muted-foreground mt-1">por mês</p>
              </div>

              <ul className="space-y-3 mb-8">
                {plano.features.map((feature, idx) => (
                  <li key={idx} className="flex items-start gap-3 text-sm">
                    <Check className="w-4 h-4 text-primary shrink-0 mt-0.5" />
                    <span>{feature}</span>
                  </li>
                ))}
              </ul>

              <div className="space-y-3">
                <Link to="/registar">
                  <Button
                    variant={plano.variant}
                    className="w-full"
                    size="lg"
                  >
                    Começar Agora
                  </Button>
                </Link>
                <a
                  href={getWhatsAppLink(plano.name, plano.price)}
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  <Button
                    variant="outline"
                    className="w-full bg-[#25D366]/10 border-[#25D366] text-[#25D366] hover:bg-[#25D366] hover:text-white"
                    size="lg"
                  >
                    <MessageCircle className="w-5 h-5 mr-2" />
                    Pagar via WhatsApp
                  </Button>
                </a>
              </div>
            </div>
          ))}
        </div>

        {/* FAQ or Additional Info */}
        <div className="mt-16 text-center">
          <p className="text-muted-foreground">
            Precisa de ajuda para escolher?{" "}
            <a href="mailto:contacto@lumenai.ao" className="text-primary hover:underline">
              Fale connosco
            </a>
          </p>
        </div>
      </div>
    </div>
  );
}
