import { useState } from "react";
import {
  Calculator,
  ChevronDown,
  ChevronRight,
  Search,
  Info,
} from "lucide-react";
import { planoContas, classesDescricao, ContaPGC } from "@/data/planoContas";
import { cn } from "@/lib/utils";

const classeColors: Record<number, string> = {
  1: "bg-blue-500/10 text-blue-600 border-blue-500/20",
  2: "bg-amber-500/10 text-amber-600 border-amber-500/20",
  3: "bg-purple-500/10 text-purple-600 border-purple-500/20",
  4: "bg-emerald-500/10 text-emerald-600 border-emerald-500/20",
  5: "bg-pink-500/10 text-pink-600 border-pink-500/20",
  6: "bg-green-500/10 text-green-600 border-green-500/20",
  7: "bg-red-500/10 text-red-600 border-red-500/20",
  8: "bg-indigo-500/10 text-indigo-600 border-indigo-500/20",
};

function ContaItem({
  conta,
  level = 0,
}: {
  conta: ContaPGC;
  level?: number;
}) {
  const [expanded, setExpanded] = useState(false);
  const hasSubcontas = conta.subcontas && conta.subcontas.length > 0;

  return (
    <div>
      <div
        className={cn(
          "flex items-center gap-3 py-3 px-4 hover:bg-secondary/50 transition-colors cursor-pointer border-l-2",
          classeColors[conta.classe]
        )}
        style={{ paddingLeft: `${level * 20 + 16}px` }}
        onClick={() => hasSubcontas && setExpanded(!expanded)}
      >
        {hasSubcontas ? (
          expanded ? (
            <ChevronDown className="w-4 h-4 shrink-0" />
          ) : (
            <ChevronRight className="w-4 h-4 shrink-0" />
          )
        ) : (
          <div className="w-4" />
        )}
        <span className="font-mono font-medium w-12">{conta.codigo}</span>
        <span className="flex-1">{conta.descricao}</span>
        <span
          className={cn(
            "text-xs px-2 py-1 rounded-full",
            conta.natureza === "devedora"
              ? "bg-primary/10 text-primary"
              : "bg-success/10 text-success"
          )}
        >
          {conta.natureza === "devedora" ? "D" : "C"}
        </span>
        <span className="text-xs text-muted-foreground">{conta.tipo}</span>
      </div>
      {expanded && hasSubcontas && (
        <div className="animate-fade-in">
          {conta.subcontas!.map((subconta) => (
            <ContaItem key={subconta.codigo} conta={subconta} level={level + 1} />
          ))}
        </div>
      )}
    </div>
  );
}

export default function PlanoContas() {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedClasse, setSelectedClasse] = useState<number | null>(null);

  const filteredContas = planoContas.filter((conta) => {
    const matchesSearch =
      conta.codigo.includes(searchTerm) ||
      conta.descricao.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesClasse = selectedClasse === null || conta.classe === selectedClasse;
    return matchesSearch && matchesClasse;
  });

  return (
    <div className="min-h-screen">
      {/* Header */}
      <header className="sticky top-0 z-10 bg-background/80 backdrop-blur-lg border-b border-border">
        <div className="flex items-center justify-between px-6 py-4">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center">
              <Calculator className="w-6 h-6 text-primary" />
            </div>
            <div>
              <h1 className="text-2xl font-bold">Plano de Contas</h1>
              <p className="text-sm text-muted-foreground">
                PGC Angolano - Decreto nº 82/2001
              </p>
            </div>
          </div>
        </div>
      </header>

      {/* Content */}
      <div className="p-6">
        {/* Info Banner */}
        <div className="bg-primary/5 border border-primary/20 rounded-xl p-4 mb-6 flex items-start gap-4 animate-fade-up">
          <Info className="w-5 h-5 text-primary mt-0.5 shrink-0" />
          <div>
            <p className="font-medium text-primary">
              Plano Geral de Contabilidade de Angola
            </p>
            <p className="text-sm text-muted-foreground mt-1">
              O PGC foi aprovado pelo Decreto nº 82/2001 de 16 de Novembro e organiza as
              contas em 8 classes fundamentais, desde a Classe 1 (Meios Fixos) até à
              Classe 8 (Resultados).
            </p>
          </div>
        </div>

        {/* Classes Filter */}
        <div className="flex flex-wrap gap-2 mb-6">
          <button
            onClick={() => setSelectedClasse(null)}
            className={cn(
              "px-4 py-2 rounded-lg text-sm font-medium transition-colors",
              selectedClasse === null
                ? "bg-primary text-primary-foreground"
                : "bg-secondary hover:bg-secondary/80"
            )}
          >
            Todas
          </button>
          {Object.entries(classesDescricao).map(([classe, descricao]) => (
            <button
              key={classe}
              onClick={() => setSelectedClasse(Number(classe))}
              className={cn(
                "px-4 py-2 rounded-lg text-sm font-medium transition-colors",
                selectedClasse === Number(classe)
                  ? "bg-primary text-primary-foreground"
                  : "bg-secondary hover:bg-secondary/80"
              )}
            >
              Classe {classe}
            </button>
          ))}
        </div>

        {/* Search */}
        <div className="relative mb-6">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <input
            type="text"
            placeholder="Pesquisar por código ou descrição..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-3 bg-secondary rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-primary"
          />
        </div>

        {/* Classes Overview */}
        {selectedClasse === null && !searchTerm && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
            {Object.entries(classesDescricao).map(([classe, descricao]) => (
              <button
                key={classe}
                onClick={() => setSelectedClasse(Number(classe))}
                className={cn(
                  "p-4 rounded-xl border text-left transition-all hover:scale-[1.02]",
                  classeColors[Number(classe)]
                )}
              >
                <p className="text-3xl font-bold mb-1">{classe}</p>
                <p className="text-sm font-medium">{descricao}</p>
              </button>
            ))}
          </div>
        )}

        {/* Accounts List */}
        <div className="bg-card rounded-xl border border-border shadow-card overflow-hidden animate-fade-up">
          <div className="p-4 border-b border-border bg-secondary/50">
            <div className="flex items-center gap-3">
              <span className="font-mono font-medium w-12 text-sm text-muted-foreground">
                Código
              </span>
              <span className="flex-1 text-sm font-medium text-muted-foreground">
                Descrição
              </span>
              <span className="text-sm text-muted-foreground w-8">Nat.</span>
              <span className="text-sm text-muted-foreground">Tipo</span>
            </div>
          </div>
          <div className="divide-y divide-border">
            {filteredContas.map((conta) => (
              <ContaItem key={conta.codigo} conta={conta} />
            ))}
          </div>
          {filteredContas.length === 0 && (
            <div className="p-8 text-center text-muted-foreground">
              Nenhuma conta encontrada
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
