import { BarChart3, Download, Printer, ArrowUp, ArrowDown } from "lucide-react";
import { demonstracaoResultados } from "@/data/mockData";

const formatCurrency = (value: number) => {
  return new Intl.NumberFormat("pt-AO", {
    style: "currency",
    currency: "AOA",
    minimumFractionDigits: 0,
  }).format(value);
};

export default function Demonstracao() {
  const totalProveitos = demonstracaoResultados.proveitos.reduce(
    (sum, item) => sum + item.valor,
    0
  );
  const totalCustos = demonstracaoResultados.custos.reduce(
    (sum, item) => sum + item.valor,
    0
  );
  const resultadoLiquido = totalProveitos - totalCustos;

  return (
    <div className="min-h-screen">
      {/* Header */}
      <header className="sticky top-0 z-10 bg-background/80 backdrop-blur-lg border-b border-border">
        <div className="flex items-center justify-between px-6 py-4">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-success/10 flex items-center justify-center">
              <BarChart3 className="w-6 h-6 text-success" />
            </div>
            <div>
              <h1 className="text-2xl font-bold">Demonstração de Resultados</h1>
              <p className="text-sm text-muted-foreground">
                Exercício de 2024 • PGC Angolano
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button className="flex items-center gap-2 px-4 py-2 bg-secondary hover:bg-secondary/80 rounded-lg transition-colors">
              <Printer className="w-4 h-4" />
              <span className="text-sm font-medium">Imprimir</span>
            </button>
            <button className="flex items-center gap-2 px-4 py-2 bg-primary text-primary-foreground hover:bg-primary/90 rounded-lg transition-colors">
              <Download className="w-4 h-4" />
              <span className="text-sm font-medium">Exportar</span>
            </button>
          </div>
        </div>
      </header>

      {/* Content */}
      <div className="p-6">
        {/* Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
          <div className="bg-card rounded-xl border border-border p-6 shadow-card animate-fade-up">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-xl bg-success/10 flex items-center justify-center">
                <ArrowDown className="w-6 h-6 text-success" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Total Proveitos</p>
                <p className="text-2xl font-bold text-success">
                  {formatCurrency(totalProveitos)}
                </p>
              </div>
            </div>
          </div>
          <div className="bg-card rounded-xl border border-border p-6 shadow-card animate-fade-up">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-xl bg-destructive/10 flex items-center justify-center">
                <ArrowUp className="w-6 h-6 text-destructive" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Total Custos</p>
                <p className="text-2xl font-bold text-destructive">
                  {formatCurrency(totalCustos)}
                </p>
              </div>
            </div>
          </div>
          <div className="bg-card rounded-xl border border-border p-6 shadow-card animate-fade-up">
            <div className="flex items-center gap-4">
              <div
                className={`w-12 h-12 rounded-xl flex items-center justify-center ${
                  resultadoLiquido >= 0 ? "bg-primary/10" : "bg-destructive/10"
                }`}
              >
                <BarChart3
                  className={`w-6 h-6 ${
                    resultadoLiquido >= 0 ? "text-primary" : "text-destructive"
                  }`}
                />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Resultado Líquido</p>
                <p
                  className={`text-2xl font-bold ${
                    resultadoLiquido >= 0 ? "text-primary" : "text-destructive"
                  }`}
                >
                  {formatCurrency(resultadoLiquido)}
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* DR Table */}
        <div className="bg-card rounded-xl border border-border shadow-card overflow-hidden animate-fade-up">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-border bg-secondary/50">
                  <th className="text-left p-4 font-semibold text-sm">Conta</th>
                  <th className="text-left p-4 font-semibold text-sm">Designação</th>
                  <th className="text-right p-4 font-semibold text-sm">Valor (AOA)</th>
                </tr>
              </thead>
              <tbody>
                {/* Proveitos */}
                <tr className="bg-success/5">
                  <td colSpan={3} className="p-4 font-bold text-success uppercase">
                    Classe 6 - Proveitos e Ganhos
                  </td>
                </tr>
                {demonstracaoResultados.proveitos.map((item) => (
                  <tr
                    key={item.conta}
                    className="border-b border-border hover:bg-secondary/30 transition-colors"
                  >
                    <td className="p-4 font-mono text-primary">{item.conta}</td>
                    <td className="p-4">{item.descricao}</td>
                    <td className="p-4 text-right font-mono text-success">
                      {formatCurrency(item.valor)}
                    </td>
                  </tr>
                ))}
                <tr className="bg-success/10 font-semibold">
                  <td colSpan={2} className="p-4">Total Proveitos</td>
                  <td className="p-4 text-right font-mono text-success">
                    {formatCurrency(totalProveitos)}
                  </td>
                </tr>

                {/* Custos */}
                <tr className="bg-destructive/5">
                  <td colSpan={3} className="p-4 font-bold text-destructive uppercase">
                    Classe 7 - Custos e Perdas
                  </td>
                </tr>
                {demonstracaoResultados.custos.map((item) => (
                  <tr
                    key={item.conta}
                    className="border-b border-border hover:bg-secondary/30 transition-colors"
                  >
                    <td className="p-4 font-mono text-destructive">{item.conta}</td>
                    <td className="p-4">{item.descricao}</td>
                    <td className="p-4 text-right font-mono text-destructive">
                      ({formatCurrency(item.valor)})
                    </td>
                  </tr>
                ))}
                <tr className="bg-destructive/10 font-semibold">
                  <td colSpan={2} className="p-4">Total Custos</td>
                  <td className="p-4 text-right font-mono text-destructive">
                    ({formatCurrency(totalCustos)})
                  </td>
                </tr>

                {/* Resultado */}
                <tr className="bg-primary/10 font-bold text-lg">
                  <td colSpan={2} className="p-4 text-primary">
                    RESULTADO LÍQUIDO DO EXERCÍCIO
                  </td>
                  <td
                    className={`p-4 text-right font-mono ${
                      resultadoLiquido >= 0 ? "text-success" : "text-destructive"
                    }`}
                  >
                    {formatCurrency(resultadoLiquido)}
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>

        {/* Ratios */}
        <div className="mt-6 grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-card rounded-xl border border-border p-6 shadow-card animate-fade-up">
            <h3 className="text-sm font-semibold text-muted-foreground mb-2">
              Margem Líquida
            </h3>
            <p className="text-3xl font-bold">
              {((resultadoLiquido / totalProveitos) * 100).toFixed(1)}%
            </p>
            <p className="text-xs text-muted-foreground mt-1">
              Resultado / Proveitos
            </p>
          </div>
          <div className="bg-card rounded-xl border border-border p-6 shadow-card animate-fade-up">
            <h3 className="text-sm font-semibold text-muted-foreground mb-2">
              Rácio de Eficiência
            </h3>
            <p className="text-3xl font-bold">
              {((totalCustos / totalProveitos) * 100).toFixed(1)}%
            </p>
            <p className="text-xs text-muted-foreground mt-1">
              Custos / Proveitos
            </p>
          </div>
          <div className="bg-card rounded-xl border border-border p-6 shadow-card animate-fade-up">
            <h3 className="text-sm font-semibold text-muted-foreground mb-2">
              Custo com Pessoal / Receita
            </h3>
            <p className="text-3xl font-bold">
              {((18200000 / totalProveitos) * 100).toFixed(1)}%
            </p>
            <p className="text-xs text-muted-foreground mt-1">
              Classe 73 / Total Proveitos
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
