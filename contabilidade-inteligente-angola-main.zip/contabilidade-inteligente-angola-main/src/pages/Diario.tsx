import { useState } from "react";
import {
  BookOpen,
  Plus,
  Filter,
  Download,
  Search,
  ArrowUpDown,
  Eye,
} from "lucide-react";
import { lancamentosDiario } from "@/data/mockData";

const formatCurrency = (value: number) => {
  return new Intl.NumberFormat("pt-AO", {
    style: "currency",
    currency: "AOA",
    minimumFractionDigits: 0,
  }).format(value);
};

const formatDate = (dateString: string) => {
  return new Date(dateString).toLocaleDateString("pt-AO", {
    day: "2-digit",
    month: "short",
    year: "numeric",
  });
};

export default function Diario() {
  const [searchTerm, setSearchTerm] = useState("");

  const filteredLancamentos = lancamentosDiario.filter(
    (l) =>
      l.descricao.toLowerCase().includes(searchTerm.toLowerCase()) ||
      l.documento.toLowerCase().includes(searchTerm.toLowerCase()) ||
      l.contaDebito.toLowerCase().includes(searchTerm.toLowerCase()) ||
      l.contaCredito.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const totalMovimentos = filteredLancamentos.reduce((sum, l) => sum + l.valor, 0);

  return (
    <div className="min-h-screen">
      {/* Header */}
      <header className="sticky top-0 z-10 bg-background/80 backdrop-blur-lg border-b border-border">
        <div className="flex items-center justify-between px-6 py-4">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-warning/10 flex items-center justify-center">
              <BookOpen className="w-6 h-6 text-warning" />
            </div>
            <div>
              <h1 className="text-2xl font-bold">Diário Contabilístico</h1>
              <p className="text-sm text-muted-foreground">
                Registo cronológico de movimentos
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button className="flex items-center gap-2 px-4 py-2 bg-secondary hover:bg-secondary/80 rounded-lg transition-colors">
              <Download className="w-4 h-4" />
              <span className="text-sm font-medium">Exportar</span>
            </button>
            <button className="flex items-center gap-2 px-4 py-2 bg-primary text-primary-foreground hover:bg-primary/90 rounded-lg transition-colors">
              <Plus className="w-4 h-4" />
              <span className="text-sm font-medium">Novo Lançamento</span>
            </button>
          </div>
        </div>
      </header>

      {/* Content */}
      <div className="p-6">
        {/* Filters */}
        <div className="bg-card rounded-xl border border-border p-4 shadow-card mb-6 animate-fade-up">
          <div className="flex flex-wrap items-center gap-4">
            <div className="relative flex-1 min-w-[200px]">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <input
                type="text"
                placeholder="Pesquisar lançamentos..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-2 bg-secondary rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-primary"
              />
            </div>
            <button className="flex items-center gap-2 px-4 py-2 bg-secondary hover:bg-secondary/80 rounded-lg transition-colors">
              <Filter className="w-4 h-4" />
              <span className="text-sm font-medium">Filtros</span>
            </button>
            <button className="flex items-center gap-2 px-4 py-2 bg-secondary hover:bg-secondary/80 rounded-lg transition-colors">
              <ArrowUpDown className="w-4 h-4" />
              <span className="text-sm font-medium">Ordenar</span>
            </button>
          </div>
        </div>

        {/* Summary */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
          <div className="bg-card rounded-xl border border-border p-6 shadow-card animate-fade-up">
            <p className="text-sm text-muted-foreground">Total de Lançamentos</p>
            <p className="text-3xl font-bold">{filteredLancamentos.length}</p>
          </div>
          <div className="bg-card rounded-xl border border-border p-6 shadow-card animate-fade-up">
            <p className="text-sm text-muted-foreground">Valor Total Movimentado</p>
            <p className="text-3xl font-bold">{formatCurrency(totalMovimentos)}</p>
          </div>
          <div className="bg-card rounded-xl border border-border p-6 shadow-card animate-fade-up">
            <p className="text-sm text-muted-foreground">Período</p>
            <p className="text-3xl font-bold">Janeiro 2024</p>
          </div>
        </div>

        {/* Table */}
        <div className="bg-card rounded-xl border border-border shadow-card overflow-hidden animate-fade-up">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-border bg-secondary/50">
                  <th className="text-left p-4 font-semibold text-sm">Data</th>
                  <th className="text-left p-4 font-semibold text-sm">Documento</th>
                  <th className="text-left p-4 font-semibold text-sm">Descrição</th>
                  <th className="text-left p-4 font-semibold text-sm">Débito</th>
                  <th className="text-left p-4 font-semibold text-sm">Crédito</th>
                  <th className="text-right p-4 font-semibold text-sm">Valor</th>
                  <th className="text-center p-4 font-semibold text-sm">Ações</th>
                </tr>
              </thead>
              <tbody>
                {filteredLancamentos.map((lancamento, index) => (
                  <tr
                    key={lancamento.id}
                    className="border-b border-border hover:bg-secondary/30 transition-colors"
                    style={{ animationDelay: `${index * 50}ms` }}
                  >
                    <td className="p-4 text-sm">{formatDate(lancamento.data)}</td>
                    <td className="p-4">
                      <span className="px-2 py-1 bg-primary/10 text-primary rounded-md text-xs font-mono">
                        {lancamento.documento}
                      </span>
                    </td>
                    <td className="p-4 text-sm max-w-[200px] truncate">
                      {lancamento.descricao}
                    </td>
                    <td className="p-4 text-sm font-mono text-primary">
                      {lancamento.contaDebito}
                    </td>
                    <td className="p-4 text-sm font-mono text-success">
                      {lancamento.contaCredito}
                    </td>
                    <td className="p-4 text-right font-mono font-medium">
                      {formatCurrency(lancamento.valor)}
                    </td>
                    <td className="p-4 text-center">
                      <button className="p-2 hover:bg-secondary rounded-lg transition-colors">
                        <Eye className="w-4 h-4 text-muted-foreground" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
              <tfoot>
                <tr className="bg-secondary/50 font-semibold">
                  <td colSpan={5} className="p-4 text-right">
                    Total
                  </td>
                  <td className="p-4 text-right font-mono">
                    {formatCurrency(totalMovimentos)}
                  </td>
                  <td></td>
                </tr>
              </tfoot>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}
