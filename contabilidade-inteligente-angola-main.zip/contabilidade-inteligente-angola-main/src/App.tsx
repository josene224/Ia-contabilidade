import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { AppLayout } from "@/components/layout/AppLayout";
import Dashboard from "./pages/Dashboard";
import Assistente from "./pages/Assistente";
import Balanco from "./pages/Balanco";
import Demonstracao from "./pages/Demonstracao";
import Diario from "./pages/Diario";
import PlanoContas from "./pages/PlanoContas";
import Configuracoes from "./pages/Configuracoes";
import Login from "./pages/Login";
import Registar from "./pages/Registar";
import Planos from "./pages/Planos";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <Routes>
          {/* Public routes */}
          <Route path="/login" element={<Login />} />
          <Route path="/registar" element={<Registar />} />
          <Route path="/planos" element={<Planos />} />
          
          {/* Protected routes with AppLayout */}
          <Route
            path="/*"
            element={
              <AppLayout>
                <Routes>
                  <Route path="/" element={<Dashboard />} />
                  <Route path="/assistente" element={<Assistente />} />
                  <Route path="/balanco" element={<Balanco />} />
                  <Route path="/demonstracao" element={<Demonstracao />} />
                  <Route path="/diario" element={<Diario />} />
                  <Route path="/plano-contas" element={<PlanoContas />} />
                  <Route path="/configuracoes" element={<Configuracoes />} />
                  <Route path="*" element={<NotFound />} />
                </Routes>
              </AppLayout>
            }
          />
        </Routes>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
