// Dados de demonstração para o sistema ContaAI

export interface LancamentoDiario {
  id: string;
  data: string;
  documento: string;
  descricao: string;
  contaDebito: string;
  contaCredito: string;
  valor: number;
}

export interface SaldoConta {
  conta: string;
  descricao: string;
  debito: number;
  credito: number;
  saldo: number;
}

export const lancamentosDiario: LancamentoDiario[] = [
  {
    id: "1",
    data: "2024-01-02",
    documento: "FAT-001",
    descricao: "Venda de mercadorias a Cliente ABC",
    contaDebito: "31 - Clientes",
    contaCredito: "61 - Vendas",
    valor: 2500000,
  },
  {
    id: "2",
    data: "2024-01-05",
    documento: "REC-001",
    descricao: "Recebimento Cliente ABC",
    contaDebito: "43 - Caixa",
    contaCredito: "31 - Clientes",
    valor: 2500000,
  },
  {
    id: "3",
    data: "2024-01-08",
    documento: "FAT-F-001",
    descricao: "Compra de mercadorias Fornecedor XYZ",
    contaDebito: "26 - Mercadorias",
    contaCredito: "32 - Fornecedores",
    valor: 1200000,
  },
  {
    id: "4",
    data: "2024-01-10",
    documento: "PAG-001",
    descricao: "Pagamento Fornecedor XYZ",
    contaDebito: "32 - Fornecedores",
    contaCredito: "42 - Depósitos Bancários",
    valor: 1200000,
  },
  {
    id: "5",
    data: "2024-01-15",
    documento: "FOL-001",
    descricao: "Processamento de salários Janeiro",
    contaDebito: "73 - Custos com Pessoal",
    contaCredito: "42 - Depósitos Bancários",
    valor: 3500000,
  },
  {
    id: "6",
    data: "2024-01-18",
    documento: "FAT-002",
    descricao: "Prestação de serviços consultoria",
    contaDebito: "31 - Clientes",
    contaCredito: "62 - Prestações de Serviços",
    valor: 890000,
  },
  {
    id: "7",
    data: "2024-01-20",
    documento: "FSE-001",
    descricao: "Pagamento de renda escritório",
    contaDebito: "72 - FSE",
    contaCredito: "42 - Depósitos Bancários",
    valor: 450000,
  },
  {
    id: "8",
    data: "2024-01-22",
    documento: "DEP-001",
    descricao: "Amortização equipamento básico",
    contaDebito: "76 - Amortizações",
    contaCredito: "18 - Amortizações Acumuladas",
    valor: 250000,
  },
];

export const balancoData = {
  activo: {
    naoCorrente: [
      { conta: "11", descricao: "Imobilizações Corpóreas", valor: 45000000 },
      { conta: "12", descricao: "Imobilizações Incorpóreas", valor: 5000000 },
      { conta: "18", descricao: "Amortizações Acumuladas", valor: -12000000 },
    ],
    corrente: [
      { conta: "26", descricao: "Mercadorias", valor: 8500000 },
      { conta: "31", descricao: "Clientes", valor: 12300000 },
      { conta: "42", descricao: "Depósitos Bancários", valor: 18500000 },
      { conta: "43", descricao: "Caixa", valor: 2500000 },
    ],
  },
  capitalProprio: [
    { conta: "51", descricao: "Capital Social", valor: 50000000 },
    { conta: "55", descricao: "Reservas", valor: 8000000 },
    { conta: "59", descricao: "Resultados Transitados", valor: 5500000 },
    { conta: "88", descricao: "Resultado do Exercício", valor: 4300000 },
  ],
  passivo: {
    naoCorrente: [
      { conta: "35", descricao: "Empréstimos de MLP", valor: 8000000 },
    ],
    corrente: [
      { conta: "32", descricao: "Fornecedores", valor: 3200000 },
      { conta: "34", descricao: "Estado e Outros Entes", valor: 800000 },
    ],
  },
};

export const demonstracaoResultados = {
  proveitos: [
    { conta: "61", descricao: "Vendas", valor: 72500000 },
    { conta: "62", descricao: "Prestações de Serviços", valor: 8900000 },
    { conta: "68", descricao: "Proveitos Financeiros", valor: 350000 },
  ],
  custos: [
    { conta: "71", descricao: "Custo das Mercadorias Vendidas", valor: 42000000 },
    { conta: "72", descricao: "FSE", valor: 12500000 },
    { conta: "73", descricao: "Custos com Pessoal", valor: 18200000 },
    { conta: "76", descricao: "Amortizações", valor: 3000000 },
    { conta: "78", descricao: "Custos Financeiros", valor: 850000 },
  ],
};
