// Plano Geral de Contabilidade Angolano - Decreto nº 82/2001 de 16 de Novembro

export interface ContaPGC {
  codigo: string;
  descricao: string;
  classe: number;
  natureza: "devedora" | "credora";
  tipo: "sintética" | "analítica";
  subcontas?: ContaPGC[];
}

export const classesDescricao = {
  1: "Meios Fixos e Investimentos",
  2: "Existências",
  3: "Terceiros",
  4: "Meios Monetários",
  5: "Capital e Reservas",
  6: "Proveitos e Ganhos por Natureza",
  7: "Custos e Perdas por Natureza",
  8: "Resultados",
};

export const planoContas: ContaPGC[] = [
  // Classe 1 - Meios Fixos e Investimentos
  {
    codigo: "11",
    descricao: "Imobilizações Corpóreas",
    classe: 1,
    natureza: "devedora",
    tipo: "sintética",
    subcontas: [
      { codigo: "111", descricao: "Terrenos e Recursos Naturais", classe: 1, natureza: "devedora", tipo: "analítica" },
      { codigo: "112", descricao: "Edifícios e Outras Construções", classe: 1, natureza: "devedora", tipo: "analítica" },
      { codigo: "113", descricao: "Equipamento Básico", classe: 1, natureza: "devedora", tipo: "analítica" },
      { codigo: "114", descricao: "Equipamento de Transporte", classe: 1, natureza: "devedora", tipo: "analítica" },
      { codigo: "115", descricao: "Equipamento Administrativo", classe: 1, natureza: "devedora", tipo: "analítica" },
    ],
  },
  {
    codigo: "12",
    descricao: "Imobilizações Incorpóreas",
    classe: 1,
    natureza: "devedora",
    tipo: "sintética",
    subcontas: [
      { codigo: "121", descricao: "Trespasses", classe: 1, natureza: "devedora", tipo: "analítica" },
      { codigo: "122", descricao: "Despesas de Investigação", classe: 1, natureza: "devedora", tipo: "analítica" },
      { codigo: "123", descricao: "Propriedade Industrial", classe: 1, natureza: "devedora", tipo: "analítica" },
    ],
  },
  {
    codigo: "18",
    descricao: "Amortizações Acumuladas",
    classe: 1,
    natureza: "credora",
    tipo: "sintética",
  },
  // Classe 2 - Existências
  {
    codigo: "21",
    descricao: "Compras",
    classe: 2,
    natureza: "devedora",
    tipo: "sintética",
  },
  {
    codigo: "22",
    descricao: "Matérias-Primas",
    classe: 2,
    natureza: "devedora",
    tipo: "sintética",
  },
  {
    codigo: "23",
    descricao: "Produtos e Trabalhos em Curso",
    classe: 2,
    natureza: "devedora",
    tipo: "sintética",
  },
  {
    codigo: "26",
    descricao: "Mercadorias",
    classe: 2,
    natureza: "devedora",
    tipo: "sintética",
  },
  // Classe 3 - Terceiros
  {
    codigo: "31",
    descricao: "Clientes",
    classe: 3,
    natureza: "devedora",
    tipo: "sintética",
    subcontas: [
      { codigo: "311", descricao: "Clientes c/c", classe: 3, natureza: "devedora", tipo: "analítica" },
      { codigo: "312", descricao: "Clientes - Títulos a Receber", classe: 3, natureza: "devedora", tipo: "analítica" },
    ],
  },
  {
    codigo: "32",
    descricao: "Fornecedores",
    classe: 3,
    natureza: "credora",
    tipo: "sintética",
    subcontas: [
      { codigo: "321", descricao: "Fornecedores c/c", classe: 3, natureza: "credora", tipo: "analítica" },
      { codigo: "322", descricao: "Fornecedores - Títulos a Pagar", classe: 3, natureza: "credora", tipo: "analítica" },
    ],
  },
  {
    codigo: "34",
    descricao: "Estado",
    classe: 3,
    natureza: "devedora",
    tipo: "sintética",
    subcontas: [
      { codigo: "341", descricao: "Imposto sobre o Rendimento", classe: 3, natureza: "devedora", tipo: "analítica" },
      { codigo: "342", descricao: "Retenção de Impostos", classe: 3, natureza: "credora", tipo: "analítica" },
      { codigo: "343", descricao: "IVA", classe: 3, natureza: "devedora", tipo: "analítica" },
    ],
  },
  // Classe 4 - Meios Monetários
  {
    codigo: "41",
    descricao: "Títulos Negociáveis",
    classe: 4,
    natureza: "devedora",
    tipo: "sintética",
  },
  {
    codigo: "42",
    descricao: "Depósitos Bancários",
    classe: 4,
    natureza: "devedora",
    tipo: "sintética",
    subcontas: [
      { codigo: "421", descricao: "Depósitos à Ordem", classe: 4, natureza: "devedora", tipo: "analítica" },
      { codigo: "422", descricao: "Depósitos a Prazo", classe: 4, natureza: "devedora", tipo: "analítica" },
    ],
  },
  {
    codigo: "43",
    descricao: "Caixa",
    classe: 4,
    natureza: "devedora",
    tipo: "sintética",
  },
  // Classe 5 - Capital e Reservas
  {
    codigo: "51",
    descricao: "Capital",
    classe: 5,
    natureza: "credora",
    tipo: "sintética",
  },
  {
    codigo: "54",
    descricao: "Prémios de Emissão",
    classe: 5,
    natureza: "credora",
    tipo: "sintética",
  },
  {
    codigo: "55",
    descricao: "Reservas",
    classe: 5,
    natureza: "credora",
    tipo: "sintética",
    subcontas: [
      { codigo: "551", descricao: "Reservas Legais", classe: 5, natureza: "credora", tipo: "analítica" },
      { codigo: "552", descricao: "Reservas Estatutárias", classe: 5, natureza: "credora", tipo: "analítica" },
    ],
  },
  {
    codigo: "59",
    descricao: "Resultados Transitados",
    classe: 5,
    natureza: "credora",
    tipo: "sintética",
  },
  // Classe 6 - Proveitos e Ganhos
  {
    codigo: "61",
    descricao: "Vendas",
    classe: 6,
    natureza: "credora",
    tipo: "sintética",
  },
  {
    codigo: "62",
    descricao: "Prestações de Serviços",
    classe: 6,
    natureza: "credora",
    tipo: "sintética",
  },
  {
    codigo: "68",
    descricao: "Proveitos e Ganhos Financeiros",
    classe: 6,
    natureza: "credora",
    tipo: "sintética",
  },
  // Classe 7 - Custos e Perdas
  {
    codigo: "71",
    descricao: "Custo das Mercadorias Vendidas",
    classe: 7,
    natureza: "devedora",
    tipo: "sintética",
  },
  {
    codigo: "72",
    descricao: "Fornecimentos e Serviços Externos",
    classe: 7,
    natureza: "devedora",
    tipo: "sintética",
  },
  {
    codigo: "73",
    descricao: "Custos com o Pessoal",
    classe: 7,
    natureza: "devedora",
    tipo: "sintética",
    subcontas: [
      { codigo: "731", descricao: "Remunerações", classe: 7, natureza: "devedora", tipo: "analítica" },
      { codigo: "732", descricao: "Encargos Sociais", classe: 7, natureza: "devedora", tipo: "analítica" },
    ],
  },
  {
    codigo: "76",
    descricao: "Amortizações do Exercício",
    classe: 7,
    natureza: "devedora",
    tipo: "sintética",
  },
  // Classe 8 - Resultados
  {
    codigo: "81",
    descricao: "Resultados Operacionais",
    classe: 8,
    natureza: "credora",
    tipo: "sintética",
  },
  {
    codigo: "82",
    descricao: "Resultados Financeiros",
    classe: 8,
    natureza: "credora",
    tipo: "sintética",
  },
  {
    codigo: "83",
    descricao: "Resultados Correntes",
    classe: 8,
    natureza: "credora",
    tipo: "sintética",
  },
  {
    codigo: "88",
    descricao: "Resultado Líquido do Exercício",
    classe: 8,
    natureza: "credora",
    tipo: "sintética",
  },
];
