import { useState, useRef, useEffect } from "react";
import { Send, Bot, User, Sparkles, Loader2 } from "lucide-react";
import { cn } from "@/lib/utils";

interface Message {
  id: string;
  role: "user" | "assistant";
  content: string;
  timestamp: Date;
}

const suggestions = [
  "Qual é o saldo atual da conta de caixa?",
  "Analise o balanço do último trimestre",
  "Como registar uma venda a prazo?",
  "Quais são as classes do PGC Angolano?",
];

export function AIChat() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "1",
      role: "assistant",
      content:
        "Olá! Sou o assistente ContaAI, especializado em contabilidade angolana segundo o PGC nº 82/2001. Como posso ajudá-lo hoje?",
      timestamp: new Date(),
    },
  ]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      role: "user",
      content: input.trim(),
      timestamp: new Date(),
    };

    setMessages((prev) => [...prev, userMessage]);
    setInput("");
    setIsLoading(true);

    // Simular resposta da IA (substituir por integração real)
    setTimeout(() => {
      const aiResponse: Message = {
        id: (Date.now() + 1).toString(),
        role: "assistant",
        content: getAIResponse(userMessage.content),
        timestamp: new Date(),
      };
      setMessages((prev) => [...prev, aiResponse]);
      setIsLoading(false);
    }, 1500);
  };

  const getAIResponse = (question: string): string => {
    const lowerQuestion = question.toLowerCase();
    
    if (lowerQuestion.includes("classe") || lowerQuestion.includes("pgc")) {
      return `O Plano Geral de Contabilidade (PGC) Angolano, aprovado pelo Decreto nº 82/2001 de 16 de Novembro, organiza as contas em 8 classes:

**Classe 1** - Meios Fixos e Investimentos
**Classe 2** - Existências
**Classe 3** - Terceiros
**Classe 4** - Meios Monetários
**Classe 5** - Capital e Reservas
**Classe 6** - Proveitos e Ganhos por Natureza
**Classe 7** - Custos e Perdas por Natureza
**Classe 8** - Resultados

Cada classe tem subdivisões específicas para facilitar a classificação contabilística.`;
    }
    
    if (lowerQuestion.includes("balanço") || lowerQuestion.includes("balanco")) {
      return `O **Balanço Patrimonial** segundo o PGC Angolano apresenta:

**ACTIVO:**
- Activo Não Corrente (Classe 1)
- Activo Corrente (Classes 2, 3, 4)

**CAPITAL PRÓPRIO E PASSIVO:**
- Capital Próprio (Classe 5)
- Passivo Não Corrente
- Passivo Corrente

O balanço deve sempre equilibrar: Activo = Passivo + Capital Próprio. Posso ajudar a analisar alguma conta específica?`;
    }
    
    if (lowerQuestion.includes("venda") || lowerQuestion.includes("prazo")) {
      return `Para registar uma **venda a prazo** no PGC Angolano:

**Débito:** 31 - Clientes (pelo valor da venda com IVA)
**Crédito:** 71 - Vendas (valor da venda sem IVA)
**Crédito:** 34 - Estado (IVA a pagar)

Exemplo para venda de 100.000 AOA + IVA 14%:
- D: 31 Clientes → 114.000 AOA
- C: 71 Vendas → 100.000 AOA
- C: 34 Estado (IVA) → 14.000 AOA`;
    }
    
    return `Baseado no PGC Angolano (Decreto nº 82/2001), posso ajudá-lo com:

• Classificação de contas nas 8 classes
• Lançamentos contabilísticos
• Demonstrações financeiras (Balanço, DR)
• Análise de rácios financeiros
• Procedimentos de fecho de exercício

Pode especificar melhor a sua dúvida para que eu possa dar uma resposta mais detalhada?`;
  };

  return (
    <div className="flex flex-col h-full bg-card rounded-xl border border-border shadow-card overflow-hidden">
      {/* Header */}
      <div className="p-4 border-b border-border bg-gradient-to-r from-primary/5 to-primary/10">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-primary flex items-center justify-center">
            <Sparkles className="w-5 h-5 text-primary-foreground" />
          </div>
          <div>
            <h2 className="font-semibold">Assistente ContaAI</h2>
            <p className="text-xs text-muted-foreground">
              Especialista em PGC Angolano
            </p>
          </div>
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map((message) => (
          <div
            key={message.id}
            className={cn(
              "flex gap-3 animate-fade-up",
              message.role === "user" && "flex-row-reverse"
            )}
          >
            <div
              className={cn(
                "w-8 h-8 rounded-lg flex items-center justify-center shrink-0",
                message.role === "assistant"
                  ? "bg-primary text-primary-foreground"
                  : "bg-secondary text-secondary-foreground"
              )}
            >
              {message.role === "assistant" ? (
                <Bot className="w-4 h-4" />
              ) : (
                <User className="w-4 h-4" />
              )}
            </div>
            <div
              className={cn(
                "max-w-[80%] rounded-xl px-4 py-3",
                message.role === "assistant"
                  ? "bg-secondary text-secondary-foreground"
                  : "bg-primary text-primary-foreground"
              )}
            >
              <p className="text-sm whitespace-pre-wrap">{message.content}</p>
              <p className="text-xs opacity-60 mt-2">
                {message.timestamp.toLocaleTimeString("pt-AO", {
                  hour: "2-digit",
                  minute: "2-digit",
                })}
              </p>
            </div>
          </div>
        ))}
        {isLoading && (
          <div className="flex gap-3 animate-fade-up">
            <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center">
              <Bot className="w-4 h-4 text-primary-foreground" />
            </div>
            <div className="bg-secondary rounded-xl px-4 py-3">
              <Loader2 className="w-5 h-5 animate-spin text-muted-foreground" />
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Suggestions */}
      {messages.length === 1 && (
        <div className="px-4 pb-2">
          <p className="text-xs text-muted-foreground mb-2">Sugestões:</p>
          <div className="flex flex-wrap gap-2">
            {suggestions.map((suggestion) => (
              <button
                key={suggestion}
                onClick={() => setInput(suggestion)}
                className="text-xs bg-secondary hover:bg-secondary/80 text-secondary-foreground px-3 py-1.5 rounded-full transition-colors"
              >
                {suggestion}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Input */}
      <div className="p-4 border-t border-border">
        <div className="flex gap-3">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && handleSend()}
            placeholder="Faça uma pergunta sobre contabilidade..."
            className="flex-1 bg-secondary rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-primary"
          />
          <button
            onClick={handleSend}
            disabled={!input.trim() || isLoading}
            className="bg-primary text-primary-foreground rounded-xl px-4 py-3 hover:bg-primary/90 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <Send className="w-5 h-5" />
          </button>
        </div>
      </div>
    </div>
  );
}
