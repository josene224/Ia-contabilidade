import { ArrowUpRight, ArrowDownLeft } from "lucide-react";
import { cn } from "@/lib/utils";

const transactions = [
  {
    id: 1,
    description: "Venda de mercadorias",
    account: "71 - Vendas",
    amount: 2500000,
    type: "credit",
    date: "2024-01-24",
  },
  {
    id: 2,
    description: "Compra de matéria-prima",
    account: "31 - Compras",
    amount: 1200000,
    type: "debit",
    date: "2024-01-23",
  },
  {
    id: 3,
    description: "Pagamento de salários",
    account: "64 - Custos c/ Pessoal",
    amount: 3500000,
    type: "debit",
    date: "2024-01-22",
  },
  {
    id: 4,
    description: "Prestação de serviços",
    account: "72 - Prestação de Serviços",
    amount: 890000,
    type: "credit",
    date: "2024-01-21",
  },
  {
    id: 5,
    description: "Pagamento de renda",
    account: "62 - FSE",
    amount: 450000,
    type: "debit",
    date: "2024-01-20",
  },
];

const formatCurrency = (value: number) => {
  return new Intl.NumberFormat("pt-AO", {
    style: "currency",
    currency: "AOA",
    minimumFractionDigits: 0,
  }).format(value);
};

const formatDate = (dateString: string) => {
  return new Date(dateString).toLocaleDateString("pt-AO", {
    day: "2-digit",
    month: "short",
  });
};

export function RecentTransactions() {
  return (
    <div className="bg-card rounded-xl border border-border p-6 shadow-card animate-fade-up">
      <div className="mb-6">
        <h3 className="text-lg font-semibold">Movimentos Recentes</h3>
        <p className="text-sm text-muted-foreground">
          Últimas transações registadas
        </p>
      </div>
      <div className="space-y-4">
        {transactions.map((transaction) => (
          <div
            key={transaction.id}
            className="flex items-center justify-between py-3 border-b border-border last:border-0"
          >
            <div className="flex items-center gap-4">
              <div
                className={cn(
                  "w-10 h-10 rounded-lg flex items-center justify-center",
                  transaction.type === "credit"
                    ? "bg-success/10 text-success"
                    : "bg-destructive/10 text-destructive"
                )}
              >
                {transaction.type === "credit" ? (
                  <ArrowDownLeft className="w-5 h-5" />
                ) : (
                  <ArrowUpRight className="w-5 h-5" />
                )}
              </div>
              <div>
                <p className="font-medium text-sm">{transaction.description}</p>
                <p className="text-xs text-muted-foreground">
                  {transaction.account}
                </p>
              </div>
            </div>
            <div className="text-right">
              <p
                className={cn(
                  "font-semibold text-sm",
                  transaction.type === "credit"
                    ? "text-success"
                    : "text-destructive"
                )}
              >
                {transaction.type === "credit" ? "+" : "-"}
                {formatCurrency(transaction.amount)}
              </p>
              <p className="text-xs text-muted-foreground">
                {formatDate(transaction.date)}
              </p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
